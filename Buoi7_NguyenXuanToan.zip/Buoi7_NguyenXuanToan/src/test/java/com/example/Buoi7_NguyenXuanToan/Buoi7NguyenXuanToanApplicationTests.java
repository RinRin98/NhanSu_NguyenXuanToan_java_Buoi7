package com.example.Buoi7_NguyenXuanToan;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Buoi7NguyenXuanToanApplicationTests {

	@Test
	void contextLoads() {
	}

}
