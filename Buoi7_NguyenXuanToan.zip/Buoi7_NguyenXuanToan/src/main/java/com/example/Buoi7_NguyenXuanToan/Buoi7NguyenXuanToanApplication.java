package com.example.Buoi7_NguyenXuanToan;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Buoi7NguyenXuanToanApplication {

	public static void main(String[] args) {
		SpringApplication.run(Buoi7NguyenXuanToanApplication.class, args);
	}

}
